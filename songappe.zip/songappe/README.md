# songappe

A mobile-friendly song discovery app and installable Progressive Web App (PWA). It uses public catalogue endpoints for song metadata and preview links; playlists and saved songs are stored locally in the browser.

## Features

- Search songs and artists with the iTunes Search API
- Browse Apple Music RSS chart results (fallback to a popular search)
- Play short previews when the catalogue provides them
- Save tracks to a local library
- Create playlists and add tracks
- Lyrics lookup via lyrics.ovh when available
- Responsive layout for mobile and desktop
- PWA manifest and service worker for installability and cached app shell

## Run locally

You can open `index.html` directly for most features, but PWA installation and service-worker caching require HTTPS or localhost. The easiest options:

1. Upload these files to a GitHub repository.
2. Open **Settings → Pages**.
3. Under **Build and deployment**, select **Deploy from a branch**, choose `main` and `/ (root)`, then save.
4. Wait for GitHub Pages to publish. Open the Pages URL over HTTPS.

If testing on a computer, run a local static server in this folder, for example `python -m http.server 8000`, then visit `http://localhost:8000`.

## Android

Open the published HTTPS URL in Chrome on Android. Use the browser menu and choose **Install app** or **Add to Home screen**. This is a PWA, not a Play Store APK. A native Android package would require a separate wrapper/build process.

## APIs and limitations

- Search: `https://itunes.apple.com/search`
- Charts: `https://rss.applemarketingtools.com`
- Lyrics: `https://api.lyrics.ovh`

These endpoints are third-party services and can change, rate-limit, or be unavailable. Track playback is limited to preview URLs supplied by the catalogue; full tracks are not hosted here. Lyrics availability is not guaranteed. This project does not download music or bypass subscription/access controls.

## Data and privacy

Saved tracks and playlists are kept in this browser's `localStorage`; they are not synced across devices. Search terms are sent to the third-party catalogue API. Avoid entering private information.

## License

MIT — see `LICENSE`.
