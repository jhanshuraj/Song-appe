const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const audio = $("#audio-player");
const state = { songs: [], queue: [], currentIndex: -1, view: "discover", search: "", playlists: loadJSON("songappe-playlists", []), liked: loadJSON("songappe-liked", []), deferredInstall: null, toastTimer: null };

function loadJSON(key, fallback) { try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; } }
function saveJSON(key, value) { try { localStorage.setItem(key, JSON.stringify(value)); } catch {} }
function escapeHTML(value = "") { return String(value).replace(/[&<>"']/g, c => ({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;" }[c])); }
function normalizeTrack(t) {
  return { id: String(t.id ?? t.trackId ?? `${t.artistName}-${t.trackName}`), title: t.name || t.trackName || "Unknown track", artist: t.artistName || t.artist || "Unknown artist", album: t.albumName || t.collectionName || "", art: (t.artworkUrl100 || t.artworkUrl600 || t.image || "").replace(/100x100bb/g, "600x600bb"), preview: t.previewUrl || t.preview_url || "", url: t.url || t.trackViewUrl || "", lyricsArtist: t.artistName || t.artist || "", lyricsTitle: t.name || t.trackName || "" };
}
function showToast(message) { const toast = $("#toast"); toast.textContent = message; toast.classList.add("show"); clearTimeout(state.toastTimer); state.toastTimer = setTimeout(() => toast.classList.remove("show"), 2500); }
function setStatus(message, show = true) { $("#status-message").textContent = message; $("#status-message").classList.toggle("hidden", !show); }
function setHeading(title, eyebrow = "MADE FOR YOUR MOOD") { $("#section-title").innerHTML = `${escapeHTML(title)} <span class="heading-arrow">↗</span>`; $("#section-eyebrow").textContent = eyebrow; }
function artFallback() { return `<div class="cover-fallback" aria-label="Music note">♫</div>`; }

function renderSongs(songs, message = "") {
  state.songs = songs;
  const grid = $("#song-grid");
  grid.innerHTML = "";
  if (!songs.length) {
    setStatus(message || "No tracks found. Try a different search.", true);
    return;
  }
  setStatus(message, Boolean(message));
  grid.innerHTML = songs.map((song, index) => {
    const liked = state.liked.some(x => x.id === song.id);
    const cover = song.art ? `<img class="cover-art" loading="lazy" src="${escapeHTML(song.art)}" alt="${escapeHTML(song.title)} cover" onerror="this.outerHTML='<div class=&quot;cover-fallback&quot;>♫</div>'">` : artFallback();
    return `<article class="song-card">
      <div class="cover-wrap">${cover}<button class="cover-play" data-play="${index}" aria-label="Play ${escapeHTML(song.title)}" title="Play preview">▶</button></div>
      <div class="song-title" title="${escapeHTML(song.title)}">${escapeHTML(song.title)}</div>
      <div class="song-artist" title="${escapeHTML(song.artist)}">${escapeHTML(song.artist)}</div>
      <div class="song-meta"><span class="song-album">${escapeHTML(song.album || "Single")}</span><div class="card-actions"><button class="mini-action" data-like="${index}" aria-label="Save ${escapeHTML(song.title)}" title="Save track">${liked ? "♥" : "♡"}</button><button class="mini-action" data-lyrics="${index}" aria-label="Find lyrics for ${escapeHTML(song.title)}" title="Find lyrics">≡</button><button class="mini-action" data-add="${index}" aria-label="Add ${escapeHTML(song.title)} to playlist" title="Add to playlist">＋</button></div></div>
    </article>`;
  }).join("");
}

async function getJSON(url) {
  const response = await fetch(url);
  if (!response.ok) throw new Error(`Request failed (${response.status})`);
  return response.json();
}
async function loadTrending() {
  setHeading("Trending right now", "THE TOP TRACKS");
  setStatus("Finding popular tracks…", true);
  $("#hero").classList.remove("hidden"); $("#quick-section").classList.remove("hidden");
  try {
    let data;
    try { data = await getJSON("https://rss.applemarketingtools.com/api/v2/in/music/most-played/25/songs.json"); }
    catch { data = await getJSON("https://rss.applemarketingtools.com/api/v2/us/music/most-played/25/songs.json"); }
    const tracks = (data.feed?.results || []).map(t => normalizeTrack({ ...t, artworkUrl100: t.artworkUrl100 || t.artworkUrl600 }));
    renderSongs(tracks, "Popular picks · Tap a track to play a preview");
  } catch {
    await searchSongs("top hits", true);
    setHeading("Popular picks", "DISCOVER SOMETHING NEW");
    setStatus("Chart feed unavailable; showing popular search results instead.", true);
  }
}
async function searchSongs(query, quiet = false) {
  state.search = query;
  if (!quiet) { setHeading(query ? `Results for “${query}”` : "Trending right now", query ? "SEARCH RESULTS" : "THE TOP TRACKS"); setStatus("Searching the music catalogue…", true); }
  if (!query.trim()) return loadTrending();
  $("#hero").classList.add("hidden"); $("#quick-section").classList.add("hidden");
  try {
    const data = await getJSON(`https://itunes.apple.com/search?term=${encodeURIComponent(query)}&entity=song&limit=30&country=in`);
    const tracks = (data.results || []).map(normalizeTrack);
    renderSongs(tracks, tracks.length ? `${tracks.length} tracks found · Previews available where provided` : "No matches found. Try another artist or song.");
  } catch {
    renderSongs([], "Couldn't connect to the music catalogue. Check your internet and try again.");
  }
}
function currentSong() { return state.queue[state.currentIndex] || null; }
function setPlayer(song) {
  $("#player-title").textContent = song.title;
  $("#player-artist").textContent = song.artist;
  $("#player-art").src = song.art || "./icon.svg";
  $("#player-art").onerror = () => { $("#player-art").src = "./icon.svg"; };
  $("#like-current").classList.toggle("saved", state.liked.some(x => x.id === song.id));
  $("#like-current").textContent = state.liked.some(x => x.id === song.id) ? "♥" : "♡";
}
async function playSong(song, list = state.songs) {
  if (!song) return;
  state.queue = list.length ? list : [song];
  state.currentIndex = Math.max(0, state.queue.findIndex(x => x.id === song.id));
  setPlayer(song);
  if (!song.preview) {
    audio.pause(); audio.removeAttribute("src"); $("#play-button").textContent = "▶";
    showToast("No playable preview for this track. Try another song.");
    if (song.url) window.open(song.url, "_blank", "noopener,noreferrer");
    return;
  }
  if (audio.src !== song.preview) audio.src = song.preview;
  try { await audio.play(); $("#play-button").textContent = "Ⅱ"; }
  catch { showToast("Tap play to start the preview."); $("#play-button").textContent = "▶"; }
}
function toggleLike(song) {
  if (!song) return;
  const found = state.liked.some(x => x.id === song.id);
  state.liked = found ? state.liked.filter(x => x.id !== song.id) : [song, ...state.liked];
  saveJSON("songappe-liked", state.liked);
  renderSidebarPlaylists();
  renderSongs(state.songs, "");
  if (currentSong()?.id === song.id) setPlayer(song);
  showToast(found ? "Removed from your saved songs" : "Saved to your library");
}
function renderSidebarPlaylists() {
  const holder = $("#sidebar-playlists");
  holder.innerHTML = state.playlists.map(p => `<button class="nav-item" data-playlist="${escapeHTML(p.id)}"><span>♫</span>${escapeHTML(p.name)}</button>`).join("");
}
function showLibrary() {
  state.view = "library"; setHeading("Your library", "SAVED FOR LATER"); $("#hero").classList.add("hidden"); $("#quick-section").classList.add("hidden");
  renderSongs(state.liked, state.liked.length ? "Your saved tracks" : "Your library is empty. Tap ♡ on a song to save it.");
}
function showPlaylist(id) {
  const playlist = state.playlists.find(p => p.id === id);
  if (!playlist) return;
  setHeading(playlist.name, "YOUR PLAYLIST"); $("#hero").classList.add("hidden"); $("#quick-section").classList.add("hidden");
  renderSongs(playlist.songs || [], playlist.songs?.length ? `${playlist.songs.length} saved track(s)` : "This playlist is empty. Use ＋ on a song to add tracks.");
}
function createPlaylist() { $("#playlist-name").value = ""; $("#playlist-dialog").showModal(); }
function addToPlaylist(song) {
  if (!song) return;
  if (!state.playlists.length) { createPlaylist(); $("#playlist-form").dataset.pendingSong = song.id; return; }
  const chosen = prompt(`Add “${song.title}” to which playlist?\n${state.playlists.map((p,i) => `${i+1}. ${p.name}`).join("\n")}\n\nEnter a playlist number:`);
  const index = Number(chosen) - 1;
  if (!Number.isInteger(index) || index < 0 || index >= state.playlists.length) return;
  const p = state.playlists[index];
  if (!p.songs.some(s => s.id === song.id)) p.songs.push(song);
  saveJSON("songappe-playlists", state.playlists); renderSidebarPlaylists(); showToast(`Added to ${p.name}`);
}
async function findLyrics(song) {
  if (!song) return;
  $("#lyrics-section").classList.remove("hidden");
  $("#lyrics-title").textContent = `${song.title} — ${song.artist}`;
  $("#lyrics-content").innerHTML = `<p class="lyrics-help">Looking for lyrics…</p>`;
  $("#lyrics-section").scrollIntoView({ behavior: "smooth", block: "start" });
  try {
    const data = await getJSON(`https://api.lyrics.ovh/v1/${encodeURIComponent(song.lyricsArtist)}/${encodeURIComponent(song.lyricsTitle)}`);
    if (!data.lyrics) throw new Error("No lyrics");
    $("#lyrics-content").textContent = data.lyrics;
  } catch {
    $("#lyrics-content").innerHTML = `<p class="lyrics-help">Lyrics weren't available from the current source. Availability varies by track and region. Try searching the song title and artist on a licensed lyrics provider.</p>${song.url ? `<p><a href="${escapeHTML(song.url)}" target="_blank" rel="noopener noreferrer">Open song page ↗</a></p>` : ""}`;
  }
}
function playNext(step) {
  if (!state.queue.length) return;
  state.currentIndex = (state.currentIndex + step + state.queue.length) % state.queue.length;
  playSong(state.queue[state.currentIndex], state.queue);
}
function formatTime(seconds) { if (!Number.isFinite(seconds)) return "0:00"; return `${Math.floor(seconds/60)}:${String(Math.floor(seconds%60)).padStart(2,"0")}`; }

$("#song-grid").addEventListener("click", e => {
  const play = e.target.closest("[data-play]"); const like = e.target.closest("[data-like]"); const add = e.target.closest("[data-add]"); const lyrics = e.target.closest("[data-lyrics]");
  if (play) playSong(state.songs[Number(play.dataset.play)], state.songs);
  if (like) toggleLike(state.songs[Number(like.dataset.like)]);
  if (add) addToPlaylist(state.songs[Number(add.dataset.add)]);
  if (lyrics) findLyrics(state.songs[Number(lyrics.dataset.lyrics)]);
});
let searchTimer;
$("#search-input").addEventListener("input", e => { clearTimeout(searchTimer); const q = e.target.value.trim(); searchTimer = setTimeout(() => q ? searchSongs(q) : loadTrending(), 350); });
$("#search-input").addEventListener("keydown", e => { if (e.key === "Enter") { clearTimeout(searchTimer); searchSongs(e.target.value.trim()); } });
$$(".nav-item[data-view]").forEach(btn => btn.addEventListener("click", () => {
  $$(".nav-item[data-view]").forEach(b => b.classList.toggle("active", b === btn));
  if (btn.dataset.view === "discover") { $("#search-input").value = ""; loadTrending(); state.view = "discover"; }
  if (btn.dataset.view === "trending") { $("#search-input").value = ""; loadTrending(); state.view = "trending"; }
  if (btn.dataset.view === "library") showLibrary();
}));
$("#hero-explore").addEventListener("click", () => { $("#search-input").focus(); $("#search-input").scrollIntoView({ behavior: "smooth", block: "center" }); });
$("#see-all").addEventListener("click", () => { if (state.search) searchSongs(state.search); else loadTrending(); });
$$(".vibe-card").forEach(btn => btn.addEventListener("click", () => { $("#search-input").value = btn.dataset.query; searchSongs(btn.dataset.query); }));
$("#create-playlist").addEventListener("click", createPlaylist);
$("#sidebar-playlists").addEventListener("click", e => { const btn = e.target.closest("[data-playlist]"); if (btn) showPlaylist(btn.dataset.playlist); });
$("#playlist-form").addEventListener("submit", e => {
  e.preventDefault();
  const name = $("#playlist-name").value.trim(); if (!name) return;
  const playlist = { id: (crypto.randomUUID?.() || String(Date.now())), name, songs: [] };
  state.playlists.push(playlist);
  const pendingId = $("#playlist-form").dataset.pendingSong;
  if (pendingId) {
    const song = state.songs.find(s => s.id === pendingId);
    if (song) playlist.songs.push(song);
    delete $("#playlist-form").dataset.pendingSong;
  }
  saveJSON("songappe-playlists", state.playlists); renderSidebarPlaylists(); $("#playlist-dialog").close(); showToast(`Created ${name}`);
});
$("#play-button").addEventListener("click", async () => {
  if (!currentSong()) { showToast("Choose a song first."); return; }
  if (!audio.src && currentSong().preview) { await playSong(currentSong(), state.queue); return; }
  if (audio.paused) { try { await audio.play(); $("#play-button").textContent = "Ⅱ"; } catch { showToast("This preview could not be played."); } }
  else { audio.pause(); $("#play-button").textContent = "▶"; }
});
$("#previous-button").addEventListener("click", () => playNext(-1));
$("#next-button").addEventListener("click", () => playNext(1));
$("#like-current").addEventListener("click", () => toggleLike(currentSong()));
$("#show-player-lyrics").addEventListener("click", () => findLyrics(currentSong()));
$("#close-lyrics").addEventListener("click", () => $("#lyrics-section").classList.add("hidden"));
audio.addEventListener("timeupdate", () => { $("#current-time").textContent = formatTime(audio.currentTime); $("#duration").textContent = formatTime(audio.duration || 30); $("#progress").value = audio.duration ? audio.currentTime / audio.duration * 100 : 0; });
audio.addEventListener("ended", () => { $("#play-button").textContent = "▶"; playNext(1); });
audio.addEventListener("pause", () => { $("#play-button").textContent = "▶"; });
audio.addEventListener("play", () => { $("#play-button").textContent = "Ⅱ"; });
$("#progress").addEventListener("input", e => { if (audio.duration) audio.currentTime = audio.duration * Number(e.target.value) / 100; });
$("#volume").addEventListener("input", e => { audio.volume = Number(e.target.value); });
audio.volume = 0.8;
window.addEventListener("beforeinstallprompt", e => { e.preventDefault(); state.deferredInstall = e; $("#install-button").classList.remove("hidden"); });
$("#install-button").addEventListener("click", async () => {
  if (!state.deferredInstall) { showToast("On Android Chrome, use the browser menu → Install app or Add to Home screen."); return; }
  state.deferredInstall.prompt(); await state.deferredInstall.userChoice; state.deferredInstall = null; $("#install-button").classList.add("hidden");
});
if ("serviceWorker" in navigator && location.protocol.startsWith("http")) window.addEventListener("load", () => navigator.serviceWorker.register("./sw.js").catch(() => {}));
renderSidebarPlaylists();
loadTrending();
